from datetime import datetime

# Listas para armazenar dados
lista_cidadaos = []
lista_profissionais = []
lista_agendamentos = []


# Cadastro de cidadão
def cadastrar_cidadao():
  nome = input("Nome: ")
  cpf = input("CPF: ")
  telefone = input("Telefone: ")
  endereco = input("Endereço: ")

  cidadao = {
      "nome": nome,
      "cpf": cpf,
      "telefone": telefone,
      "endereco": endereco
  }
  lista_cidadaos.append(cidadao)
  print("✅ Cidadão cadastrado com sucesso!\n")


# Cadastro de profissional
def cadastrar_profissional():
  nome = input("Nome: ")
  area = input("Área de Atendimento: ")

  profissional = {
      "id": len(lista_profissionais) + 1,
      "nome": nome,
      "area": area
  }
  lista_profissionais.append(profissional)
  print("✅ Profissional cadastrado com sucesso!\n")


# Gera lista de horários comerciais (08:00 às 17:00, de hora em hora)
def gerar_horarios():
  return [f"{h:02d}:00" for h in range(8, 18)]


# Verifica se já existe conflito de horário
def existe_conflito(data, horario, profissional, cpf, ignorar=None):
  for i, a in enumerate(lista_agendamentos):
    if ignorar is not None and i == ignorar:
      continue
    if a["data"] == data and a["horario"] == horario:
      if a["profissional"] == profissional:
        return "profissional"
      if a["cpf"] == cpf:
        return "cidadao"
  return None


# Retorna horários livres para um profissional em uma data
def horarios_livres(data, profissional, ignorar=None):
  livres = gerar_horarios()
  for i, a in enumerate(lista_agendamentos):
    if ignorar is not None and i == ignorar:
      continue
    if a["data"] == data and a["profissional"] == profissional:
      if a["horario"] in livres:
        livres.remove(a["horario"])
  return livres


# Agendamento
def agendar_atendimento():
  if not lista_cidadaos or not lista_profissionais:
    print("⚠️ Cadastre cidadãos e profissionais antes de agendar.")
    return

  print("\n📋 Lista de cidadãos:")
  for c in lista_cidadaos:
    print(f"- {c['cpf']} | {c['nome']}")

  cpf = input("Digite o CPF do cidadão: ")
  cidadao = next((c for c in lista_cidadaos if c['cpf'] == cpf), None)

  if not cidadao:
    print("❌ Cidadão não encontrado!")
    return

  print("\n👩‍⚕️ Lista de profissionais:")
  for p in lista_profissionais:
    print(f"{p['id']} - {p['nome']} ({p['area']})")

  try:
    id_prof = int(input("Digite o ID do profissional: "))
    profissional = next((p for p in lista_profissionais if p['id'] == id_prof),
                        None)
  except ValueError:
    print("❌ ID inválido.")
    return

  if not profissional:
    print("❌ Profissional não encontrado!")
    return

  data_str = input("Digite a data desejada (DD/MM/AAAA): ")
  try:
    data_formatada = datetime.strptime(data_str, "%d/%m/%Y").date()
  except ValueError:
    print("❌ Data inválida! Use o formato DD/MM/AAAA.")
    return

  if data_formatada.weekday() >= 5:  # sábado e domingo
    print("❌ Só é permitido agendar de segunda a sexta-feira.\n")
    return

  livres = horarios_livres(data_formatada.strftime("%d/%m/%Y"),
                           profissional["nome"])

  if not livres:
    print("⚠️ Não há horários disponíveis nesta data.\n")
    return

  print(f"\n⏰ Horários disponíveis em {data_formatada.strftime('%d/%m/%Y')}:")
  for h in livres:
    print(f"- {h}")

  horario = input("Digite o horário desejado (HH:MM): ").strip()
  if horario not in livres:
    print("❌ Horário indisponível.\n")
    return

  agendamento = {
      "cidadao": cidadao["nome"],
      "cpf": cidadao["cpf"],
      "profissional": profissional["nome"],
      "area": profissional["area"],
      "data": data_formatada.strftime("%d/%m/%Y"),
      "horario": horario
  }
  lista_agendamentos.append(agendamento)

  print("✅ Agendamento realizado com sucesso!\n")


# Visualizar agenda por data (todos)
def visualizar_agendamentos_por_data():
  data_str = input("Digite a data para consulta (DD/MM/AAAA): ")
  try:
    data_formatada = datetime.strptime(data_str, "%d/%m/%Y").date()
  except ValueError:
    print("❌ Data inválida! Use o formato DD/MM/AAAA.")
    return

  print(f"\n📅 Agendamentos para {data_formatada.strftime('%d/%m/%Y')}:")
  encontrados = False
  for a in lista_agendamentos:
    if a["data"] == data_formatada.strftime("%d/%m/%Y"):
      print(
          f"- {a['horario']} | {a['cidadao']} (CPF {a['cpf']}) com {a['profissional']} ({a['area']})"
      )
      encontrados = True
  if not encontrados:
    print("Nenhum agendamento encontrado.")


# Visualizar agenda de um profissional específico
def visualizar_agenda_profissional():
  if not lista_profissionais:
    print("⚠️ Nenhum profissional cadastrado.\n")
    return

  print("\n👩‍⚕️ Lista de profissionais:")
  for p in lista_profissionais:
    print(f"{p['id']} - {p['nome']} ({p['area']})")

  try:
    id_prof = int(input("Digite o ID do profissional: "))
    profissional = next((p for p in lista_profissionais if p['id'] == id_prof),
                        None)
  except ValueError:
    print("❌ ID inválido.")
    return

  if not profissional:
    print("❌ Profissional não encontrado!")
    return

  data_str = input("Digite a data desejada (DD/MM/AAAA): ")
  try:
    data_formatada = datetime.strptime(data_str, "%d/%m/%Y").date()
  except ValueError:
    print("❌ Data inválida! Use o formato DD/MM/AAAA.")
    return

  if data_formatada.weekday() >= 5:
    print("⚠️ Este profissional não atende aos finais de semana.\n")
    return

  print(
      f"\n📅 Agenda de {profissional['nome']} em {data_formatada.strftime('%d/%m/%Y')}:"
  )
  horarios = gerar_horarios()
  for h in horarios:
    agendamento = next(
        (a for a in lista_agendamentos
         if a["profissional"] == profissional["nome"] and a["data"] ==
         data_formatada.strftime("%d/%m/%Y") and a["horario"] == h), None)
    if agendamento:
      print(
          f"- {h} | OCUPADO com {agendamento['cidadao']} (CPF {agendamento['cpf']})"
      )
    else:
      print(f"- {h} | LIVRE")


# Cancelar agendamento
def cancelar_agendamento():
  if not lista_agendamentos:
    print("⚠️ Não existem agendamentos para cancelar.\n")
    return

  print("\n📋 Lista de agendamentos existentes:")
  for i, a in enumerate(lista_agendamentos, start=1):
    print(
        f"{i}. {a['data']} {a['horario']} | {a['cidadao']} (CPF {a['cpf']}) com {a['profissional']} ({a['area']})"
    )

  try:
    escolha = int(
        input("Digite o número do agendamento que deseja cancelar: "))
    if escolha < 1 or escolha > len(lista_agendamentos):
      print("❌ Escolha inválida.")
      return
  except ValueError:
    print("❌ Entrada inválida.")
    return

  agendamento = lista_agendamentos.pop(escolha - 1)
  print(
      f"✅ Agendamento de {agendamento['cidadao']} em {agendamento['data']} às {agendamento['horario']} foi cancelado.\n"
  )


# Editar agendamento
def editar_agendamento():
  if not lista_agendamentos:
    print("⚠️ Não existem agendamentos para editar.\n")
    return

  print("\n📋 Lista de agendamentos existentes:")
  for i, a in enumerate(lista_agendamentos, start=1):
    print(
        f"{i}. {a['data']} {a['horario']} | {a['cidadao']} (CPF {a['cpf']}) com {a['profissional']} ({a['area']})"
    )

  try:
    escolha = int(input("Digite o número do agendamento que deseja editar: "))
    if escolha < 1 or escolha > len(lista_agendamentos):
      print("❌ Escolha inválida.")
      return
  except ValueError:
    print("❌ Entrada inválida.")
    return

  agendamento = lista_agendamentos[escolha - 1]
  print(
      f"\n✏️ Editando agendamento de {agendamento['cidadao']} com {agendamento['profissional']}"
  )

  # Alterar cidadão
  print("\n📋 Lista de cidadãos cadastrados:")
  for c in lista_cidadaos:
    print(f"- {c['cpf']} | {c['nome']}")
  cpf = input("Digite o CPF do novo cidadão (ou Enter para manter): ").strip()
  if cpf:
    cidadao = next((c for c in lista_cidadaos if c['cpf'] == cpf), None)
    if cidadao:
      agendamento["cidadao"] = cidadao["nome"]
      agendamento["cpf"] = cidadao["cpf"]
    else:
      print("❌ Cidadão não encontrado! Mantendo atual.")

  # Alterar profissional
  print("\n👩‍⚕️ Lista de profissionais:")
  for p in lista_profissionais:
    print(f"{p['id']} - {p['nome']} ({p['area']})")
  id_prof = input(
      "Digite o ID do novo profissional (ou Enter para manter): ").strip()
  if id_prof:
    try:
      id_prof = int(id_prof)
      novo_prof = next((p for p in lista_profissionais if p['id'] == id_prof),
                       None)
      if novo_prof:
        agendamento["profissional"] = novo_prof["nome"]
        agendamento["area"] = novo_prof["area"]
      else:
        print("❌ Profissional não encontrado! Mantendo atual.")
    except ValueError:
      print("❌ ID inválido. Mantendo atual.")

  # Alterar data
  nova_data_str = input(
      "Digite a nova data (DD/MM/AAAA) ou Enter para manter: ").strip()
  if nova_data_str:
    try:
      nova_data = datetime.strptime(nova_data_str, "%d/%m/%Y").date()
      if nova_data.weekday() >= 5:
        print(
            "❌ Só é permitido agendar de segunda a sexta-feira. Mantendo atual."
        )
      else:
        agendamento["data"] = nova_data.strftime("%d/%m/%Y")
    except ValueError:
      print("❌ Data inválida! Mantendo atual.")

  # Alterar horário com lista de horários livres
  livres = horarios_livres(agendamento["data"],
                           agendamento["profissional"],
                           ignorar=escolha - 1)
  print(
      f"\n⏰ Horários disponíveis para {agendamento['profissional']} em {agendamento['data']}:"
  )
  for h in livres:
    print(f"- {h}")
  novo_horario = input(
      "Digite o novo horário (ou Enter para manter): ").strip()
  if novo_horario:
    if novo_horario in livres:
      agendamento["horario"] = novo_horario
    else:
      print("❌ Horário inválido! Mantendo atual.")

  print("✅ Agendamento atualizado com sucesso!\n")


# Menu principal
def menu():
  while True:
    print("\n===== Sistema Gabinete Vereadora =====")
    print("1. Cadastrar Cidadão")
    print("2. Cadastrar Profissional")
    print("3. Agendar Atendimento")
    print("4. Visualizar Agendamentos por Data")
    print("5. Visualizar Agenda de um Profissional")
    print("6. Cancelar Agendamento")
    print("7. Editar Agendamento")
    print("0. Sair")

    opcao = input("Escolha uma opção: ")

    if opcao == "1":
      cadastrar_cidadao()
    elif opcao == "2":
      cadastrar_profissional()
    elif opcao == "3":
      agendar_atendimento()
    elif opcao == "4":
      visualizar_agendamentos_por_data()
    elif opcao == "5":
      visualizar_agenda_profissional()
    elif opcao == "6":
      cancelar_agendamento()
    elif opcao == "7":
      editar_agendamento()
    elif opcao == "0":
      print("Encerrando o sistema. 👋")
      break
    else:
      print("Opção inválida. Tente novamente.")


# Executar sistema
menu()
